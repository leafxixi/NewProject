## Simple Sprite 使用说明

1. 场景中间显示一个 Sprite 图像
2. Sprite 周围有蓝色的 bounding box 紧贴图像
3. 修改 scale 属性时，Sprite 大小变化
4. 修改 anchor 位置时，Sprite 显示的位置变化
5. 点击 Sprite 资源，会高亮 Assets 面板里的贴图资源
6. 修改 size 时，Sprite 大小变化，而且 use original size 选项自动取消
7. 再次勾选 use original size 时，size 恢复到贴图尺寸